//
//  ViewController.swift
//  demopassdata
//
//  Created by Yogesh Patel on 14/12/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var txtname: UITextField!
    
    @IBOutlet var txtemail: UITextField!
    
    @IBAction func `continue`(_ sender: UIButton) {
        let sec:SecondViewController = self.storyboard?.instantiateViewController(withIdentifier: "sec") as! SecondViewController
       sec.strname = txtname.text
    sec.stremail = txtemail.text
        self.navigationController?.pushViewController(sec, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

